import UIKit

extension UIColor {
    static let primary = UIColor(red: 0/255, green: 45/255, blue: 209/255, alpha: 1)
    static let background = UIColor(red: 229/255, green: 229/255, blue: 229/255, alpha: 1)
}

